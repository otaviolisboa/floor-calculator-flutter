package com.example.floor_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
