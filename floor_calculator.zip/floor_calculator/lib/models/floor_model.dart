class FloorModel {
  double width;
  double length;
  double price;

  FloorModel(
      {this.width = 0.0,
      this.length = 0.0,
      this.price = 0.0});
}
